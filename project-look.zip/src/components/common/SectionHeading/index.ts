export { SectionHeading } from './SectionHeading';
