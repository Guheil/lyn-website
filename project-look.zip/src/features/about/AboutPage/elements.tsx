'use client';
import { styled } from '@mui/material';
export const StyledSection = styled('section')({ padding: 'clamp(72px,8vw,124px) clamp(20px,4vw,48px)' });
export const StyledInner = styled('div')({ maxWidth: 1440, margin: '0 auto' });
export const StyledProfile = styled('div')(({ theme }) => ({ display: 'grid', gridTemplateColumns: '.86fr 1.14fr', gap: 'clamp(42px,7vw,100px)', '& .photo': { minHeight: 560, background: 'url("https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?auto=format&fit=crop&w=1400&q=84") center/cover' }, [theme.breakpoints.down('lg')]: { gridTemplateColumns: '1fr', '& .photo': { minHeight: 420 } } }));
export const StyledBento = styled('div')(({ theme }) => ({ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 16, marginTop: 46, '& article': { padding: 28, border: `1px solid ${theme.palette.divider}`, background: theme.palette.background.paper, minHeight: 220 }, '& span': { color: theme.palette.primary.dark, fontWeight: 800, textTransform: 'uppercase', letterSpacing: '.12em', fontSize: '.72rem' }, [theme.breakpoints.down('md')]: { gridTemplateColumns: '1fr' } }));
