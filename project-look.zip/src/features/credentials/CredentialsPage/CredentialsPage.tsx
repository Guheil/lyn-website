import { CredentialGallery } from './CredentialGallery';
import { StyledCredentialsIntro, StyledInner, StyledSection } from './elements';

export function CredentialsPage() {
  return (
    <>
      <StyledCredentialsIntro>
        <StyledInner className="credentials-intro-grid">
          <h1>Business credentials and professional records.</h1>
          <div className="credentials-intro-copy">
            <p>
              Review registrations, permits, training documents, and affiliations connected to Lyn Bactad Property Group and its real estate operations in La Union.
            </p>
            <div className="credentials-intro-detail">
              <span>Lyn Bactad Property Group</span>
              <span>La Union, Philippines</span>
            </div>
          </div>
        </StyledInner>
      </StyledCredentialsIntro>

      <StyledSection>
        <StyledInner>
          <CredentialGallery />
        </StyledInner>
      </StyledSection>
    </>
  );
}
