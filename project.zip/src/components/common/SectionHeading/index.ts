export { SectionHeading } from './SectionHeading';
